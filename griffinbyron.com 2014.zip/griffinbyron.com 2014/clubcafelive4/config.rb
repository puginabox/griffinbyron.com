require "susy"
css_dir = 'css'
sass_dir = 'dev/sass'
javascripts_dir = 'js'
output_style = :compressed
relative_assets = true