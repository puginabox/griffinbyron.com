
$(function() {

	//	Fuild layout, centering the items
	$('#foo5').carouFredSel({
		width: '100%',
		scroll: 1,
		height: 'auto',
		prev: '#prev3',
		next: '#next3',
		auto: true
	});

});