

<!-- this pushed git changes to server -->


<?php `git pull`;  // NOTE the back-ticks (``) in php means a Shell Script (SSH)